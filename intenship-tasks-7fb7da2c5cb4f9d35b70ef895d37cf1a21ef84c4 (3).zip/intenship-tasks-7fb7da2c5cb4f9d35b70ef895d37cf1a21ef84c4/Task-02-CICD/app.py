print("Hello, CI/CD with Jenkins and Docker!")
